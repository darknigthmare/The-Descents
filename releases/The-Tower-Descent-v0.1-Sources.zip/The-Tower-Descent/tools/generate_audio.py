"""Generate original, subtle prototype sound beds; no sampled reference recordings.

Run with Python 3 from the repository root. Reproducible synthesis, mono 22050 Hz.
"""
from pathlib import Path
import math
import random
import struct
import wave

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "prototype" / "assets" / "audio"
RATE = 22050


def write(name, duration, fn):
    rng = random.Random(271104)
    buffer = bytearray()
    for i in range(int(duration * RATE)):
        t = i / RATE
        v = max(-0.95, min(0.95, fn(t, rng)))
        buffer.extend(struct.pack("<h", int(v * 32767)))
    OUT.mkdir(parents=True, exist_ok=True)
    with wave.open(str(OUT / f"{name}.wav"), "wb") as f:
        f.setnchannels(1)
        f.setsampwidth(2)
        f.setframerate(RATE)
        f.writeframes(buffer)


def wind(t, rng):
    # Periodic low tones and quiet filtered-noise-like texture, no siren imitation.
    envelope = 0.6 + 0.15 * math.sin(2 * math.pi * t / 8)
    hum = sum(math.sin(2 * math.pi * f * t) / (k + 3) for k, f in enumerate([37, 53, 71, 91]))
    return envelope * (0.17 * hum + rng.uniform(-0.06, 0.06))


if __name__ == "__main__":
    write("wind", 8, wind)
    write("radio", 0.28, lambda t, r: (0.14 * math.sin(t * 2 * math.pi * 1150) + r.uniform(-0.08, 0.08)) * math.sin(math.pi * t / 0.28) ** 2)
    write("rescue", 0.9, lambda t, r: 0.19 * math.sin(2 * math.pi * (440 if t < 0.3 else 660) * t) * math.exp(-3 * t) * min(1, t * 40))
    write("flare", 1.5, lambda t, r: (r.uniform(-0.18, 0.18) + 0.04 * math.sin(2 * math.pi * 120 * t)) * math.exp(-2.3 * t) * min(1, t * 30))
    print("Created four original WAV assets in prototype/assets/audio")
