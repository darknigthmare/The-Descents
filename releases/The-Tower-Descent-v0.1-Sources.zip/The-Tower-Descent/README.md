# The Tower Descent

**Prototype de sauvetage et d’horreur en vue subjective, accompagné de sa bible de jeu.**

Sur l’île de Nacre, une catastrophe a noyé la ville autour des tours Orphée. Une tour se penche sur sa jumelle. Votre équipe arrive sur le toit, puis les hélicoptères repartent devant le retour de la tempête. Vous descendez dans le puits central, secourez les personnes isolées et découvrez des traces d’événements antérieurs au désastre.

Le titre du jeu est **The Tower Descent**. Le dépôt conserve le nom **The-Descents**.

## Jouer au prototype

### Version Windows prête à lancer

Télécharger [The-Tower-Descent-v0.1-Windows-x64.zip](releases/The-Tower-Descent-v0.1-Windows-x64.zip), extraire le ZIP, puis lancer **TheTowerDescent.exe**. Godot n’a pas besoin d’être installé pour cette version. L’export est terminé, mais l’exécution de ce binaire sous Windows reste à vérifier sur un PC Windows.

### Projet modifiable dans Godot

Le [ZIP des sources](releases/The-Tower-Descent-v0.1-Sources.zip) contient le projet modifiable et toute la documentation. Pour l’ouvrir :

1. Télécharger ce dépôt ou le cloner.
2. Installer [Godot 4.7.2 standard](https://github.com/godotengine/godot-builds/releases/tag/4.7.2-stable), sans .NET. C’est la version utilisée pour les essais de cette livraison.
3. Dans Godot, choisir **Importer**, puis le fichier `prototype/project.godot`.
4. Ouvrir le projet et appuyer sur **F5**. Le menu permet de choisir une graine ou de reprendre un checkpoint local.

Avec Godot dans le PATH :

```sh
godot --path prototype
```

Sous Windows, `JOUER_WINDOWS.cmd` lance le même projet si `godot.exe` est dans le PATH ou si l’exécutable Godot se trouve à côté du script. Sous Linux et macOS, `./jouer.sh` utilise la commande `godot` installée.

Le projet ne demande aucun compte, service distant, clé API ou achat d’asset. Il utilise des modèles et matériaux procéduraux, et quatre sons synthétisés pour le prototype. Il reste une maquette jouable, sans les graphismes finaux d’un jeu Unreal.

## Contenu effectivement jouable

Le toit et **six étages distincts**, du 30 au 25, forment une intervention complète :

| Niveau | Lieu | Objectifs et événements |
|---|---|---|
| Toit | Poste de secours et hélicoptère | Départ de l’hélicoptère, balise de rappel, consignes radio |
| 30 | Restaurant panoramique | Secourir Ana Rios ; apprendre le retour au treuil |
| 29 | Suites | Collecter l’indice Chambre 2908 ; récupérer une caisse |
| 28 | Bureaux et archives | Secourir Samuel Breton ; danger variable selon la graine |
| 27 | Jardin d’enfants évacué | Découvrir le dessin des deux tours ; respiration sans danger |
| 26 | Spa | Secourir Nora Haddad ; relever SILLAGE 06 ; repousser la silhouette |
| 25 | Refuge technique | Se réapprovisionner et activer le relais après les trois sauvetages |

Les personnes sécurisées sont transportées au harnais de façon abstraite : votre déplacement ralentit, puis le treuil les remonte visiblement au toit. Elles sont comptées sauvées après la confirmation du poste de secours. Il n’y a pas encore d’animation complète de portage ou d’IA d’escorte.

### Commandes

| Action | Commande |
|---|---|
| Marcher | ZQSD ou WASD |
| Regarder | Souris ou flèches |
| Courir | Maj |
| S’accroupir | Ctrl |
| Sauter | Espace |
| Interagir, attacher la corde, quitter le rappel à hauteur d’un étage | E |
| Descendre en rappel | S |
| Remonter en rappel | Z ou W |
| Balancement latéral | Q ou A, et D |
| Poser un ancrage secondaire sur corde | X |
| Lampe | F |
| Fusée lumineuse | G |
| Radio | R |
| Journal | J |
| Pause et confort visuel | Échap |

Approchez une balise orange du puits et appuyez sur **E** avant de descendre. Sur corde, arrêtez-vous près d’une dalle puis appuyez à nouveau sur **E**. Les consignes s’affichent au centre de l’écran. Les ancrages secondaires stabilisent le balancement sans interrompre la ligne principale.

La réserve d’air diminue dans les étages enfumés. Les fusées repoussent la silhouette du spa pendant vingt secondes. Les refuges restent sûrs. Les mouvements de caméra sont réduits par défaut, les dialogues sont sous-titrés et le son peut être désactivé dans la pause.

## Sauvegarde

La progression s’enregistre au départ, après un treuillage confirmé et à l’activation du refuge 25. Elle conserve la graine, les ressources, les indices et les sauvetages. Un transport non encore validé n’est pas acquis : après reprise, la personne réapparaît à son emplacement.

Les sauvegardes résident dans le dossier utilisateur Godot du jeu, sous `save_v1.json`, et ne sont jamais envoyées en ligne. Une nouvelle intervention remplace le checkpoint local après un enregistrement valide. Une sauvegarde corrompue est refusée sans interrompre le menu.

## Lire la bible et préparer la suite

- [Bible au format Word](docs/The-Tower-Descent-Bible-v0.1.docx) : document réuni, mis en page et modifiable.
- [Bible au format PDF](docs/The-Tower-Descent-Bible-v0.1.pdf) : même document, prêt à lire et à partager.
- [Bible complète](docs/BIBLE_DU_JEU.md) : univers, personnages, récit, systèmes, horreur, fins et production.
- [Catalogue des étages](docs/CATALOGUE_ETAGES.md) : les trente étages, la tour condamnée, les souterrains, le bunker, le niveau 666 et Mountain Hole.
- [Génération et sauvegardes](docs/SYSTEMES_PROCEDURAUX.md) : données, invariants, reproductibilité et contraintes.
- [Architecture et portage Unreal Engine 5](docs/ARCHITECTURE_ET_PORTAGE_UE5.md) : état réel du prototype et adaptation proposée.
- [État de livraison et vérifications](docs/ETAT_DE_LIVRAISON.md) : portée des essais et fonctions restantes.

**La campagne de trente étages, Alma, la chute dans la piscine, les cavernes, le bunker, les fins et Mountain Hole sont conçus dans les documents. Ils ne sont pas implémentés dans cette version.** Le prototype est solo. Ni Unreal Engine 5 ni Unity n’ont été utilisés pour le compiler.

## Structure

```text
prototype/
  project.godot
  scenes/main.tscn
  scripts/           contrôleur, monde, rappel, interface, génération et sauvegarde
  shaders/           eau procédurale
  assets/audio/      sons originaux du prototype
  tests/             génération, persistance, mission et collisions
docs/                bible, catalogue et conception technique
tools/               scripts reproductibles de fabrication
releases/            archives Windows et sources avec sommes SHA256
dist/                version Web exportée
```

## Vérifier le projet

```sh
godot --headless --path prototype --editor --import --quit
godot --headless --path prototype --script tests/test_generation.gd
godot --headless --path prototype --script tests/test_save.gd
godot --headless --path prototype --script tests/test_mission.gd
godot --headless --fixed-fps 60 --path prototype --script tests/test_routes.gd
```

Les tests de mission utilisent des téléportations pour isoler les règles et la persistance. Les tests de trajets font se déplacer la capsule avec les collisions, sur des parcours explicitement définis. Aucun résultat de test ne certifie le rendu ou la performance sur toutes les machines.

## Références et créations

L’idée initiale et les notes sont celles de Darknigthmare. *Gremlins 2* et *Skyscraper* sont des références d’organisation des espaces et de catastrophe verticale ; leurs personnages, modèles, bandes originales et extraits ne sont pas intégrés. Le lien de sirène fourni dans le brief est une référence à examiner, pas un son téléchargé ni livré. Les noms, le programme SILLAGE, les dialogues, les géométries et les sons de cette version constituent une proposition originale de développement.

Godot et les composants qu’il embarque conservent leurs [licences respectives](docs/GODOT_LICENSES.txt), également jointes aux distributions. Ce dépôt ne modifie pas le régime de droits du projet appartenant à son auteur.
