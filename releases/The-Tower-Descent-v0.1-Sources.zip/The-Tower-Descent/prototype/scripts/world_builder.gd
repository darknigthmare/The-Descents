extends Node3D
class_name DescentWorld

## Self-contained, modular 3D greybox. Metres are the world unit.
## All gameplay corridors and interaction sockets remain outside prop jitter.

var materials: Dictionary = {}
var interactables: Array[Node3D] = []
var floor_heights: Dictionary = {}
var rng: RandomNumberGenerator = RandomNumberGenerator.new()
var rain: MultiMeshInstance3D
var rain_origin: Vector3 = Vector3.ZERO
var elapsed: float = 0.0
var specs_by_floor: Dictionary = {}
var lightning_enabled: bool = false

func build(seed_value: int, floor_specs: Array) -> Dictionary:
	rng.seed = seed_value
	_make_materials()
	_build_environment()
	_build_city()
	_build_twin_tower()
	_build_lower_shell()
	for item in floor_specs:
		if item is Dictionary:
			var number: int = int(item.get("number", item.get("floor", 0)))
			specs_by_floor[number] = item
	for number in [30, 29, 28, 27, 26, 25]:
		floor_heights[number] = float(number - 24) * 6.0
		_build_floor(number, specs_by_floor.get(number, {}))
	var roof: Dictionary = _build_roof()
	_build_rain()
	return {
		"interactables": interactables,
		"helicopter": roof["helicopter"],
		"rotor": roof["rotor"],
		"rope_top": Vector3(0, 45, 0),
		"roof_spawn": Vector3(7, 42.2, 7),
		"floor_y": floor_heights,
		"sea_level": -132.0,
		"specs": specs_by_floor
	}

func _process(delta: float) -> void:
	elapsed += delta
	if is_instance_valid(rain):
		rain.position = rain_origin + Vector3(fmod(elapsed * 1.4, 1.0), -fmod(elapsed * 14.0, 18.0), 0)
	var moon: DirectionalLight3D = get_node_or_null("StormLight")
	if is_instance_valid(moon):
		var phase: float = fmod(elapsed, 24.0)
		var pulse: float = sin(phase * PI / 0.9) * 0.8 if lightning_enabled and phase < 0.9 else 0.0
		moon.light_energy = 0.60 + pulse

func set_lightning_enabled(enabled: bool) -> void:
	lightning_enabled = enabled

func _make_materials() -> void:
	materials["concrete"] = _mat(Color("37454b"), 0.94)
	materials["edge"] = _mat(Color("687273"), 0.85)
	materials["dark"] = _mat(Color("121d25"), 0.75)
	materials["metal"] = _mat(Color("597580"), 0.34, 0.65)
	materials["black_metal"] = _mat(Color("10232e"), 0.45, 0.65)
	materials["gold"] = _mat(Color("9c7650"), 0.4, 0.7)
	materials["cream"] = _mat(Color("b5b9aa"), 0.82)
	materials["wood"] = _mat(Color("463d38"), 0.85)
	materials["orange"] = _mat(Color("e08343"), 0.65)
	materials["yellow"] = _mat(Color("cfb85a"), 0.72)
	materials["red"] = _mat(Color("924b48"), 0.78)
	materials["blue"] = _mat(Color("3d687e"), 0.8)
	materials["green"] = _mat(Color("476c5a"), 0.85)
	materials["skin"] = _mat(Color("ad8f7b"), 0.9)
	materials["white"] = _mat(Color("cad5cf"), 0.85)
	materials["lit_amber"] = _mat(Color("f6b76b"), 0.35, 0.0, 2.2)
	materials["lit_green"] = _mat(Color("68d8b5"), 0.35, 0.0, 1.6)
	materials["lit_blue"] = _mat(Color("84b7cd"), 0.4, 0.0, 1.0)
	materials["lit_red"] = _mat(Color("ef7959"), 0.35, 0.0, 2.0)
	materials["screen"] = _mat(Color("478f9c"), 0.4, 0.0, 0.7)
	materials["window"] = _mat(Color("233b48"), 0.18, 0.45)
	materials["pool"] = _mat(Color("1a6a78"), 0.15, 0.4)
	var haze: StandardMaterial3D = _mat(Color(0.48, 0.56, 0.59, 0.07), 1.0)
	haze.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	haze.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	haze.cull_mode = BaseMaterial3D.CULL_DISABLED
	materials["haze"] = haze
	var rain_mat: StandardMaterial3D = _mat(Color(0.5, 0.65, 0.7, 0.16), 1.0)
	rain_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	rain_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	materials["rain"] = rain_mat

func _mat(color: Color, roughness: float = 0.8, metallic: float = 0.0, emission: float = 0.0) -> StandardMaterial3D:
	var material: StandardMaterial3D = StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = roughness
	material.metallic = metallic
	if emission > 0.0:
		material.emission_enabled = true
		material.emission = color
		material.emission_energy_multiplier = emission
	return material

func _build_environment() -> void:
	var environment_node: WorldEnvironment = WorldEnvironment.new()
	environment_node.name = "environment"
	var environment: Environment = Environment.new()
	environment.background_mode = Environment.BG_SKY
	var sky: Sky = Sky.new()
	var sky_material: ProceduralSkyMaterial = ProceduralSkyMaterial.new()
	sky_material.sky_top_color = Color("0c1c2d")
	sky_material.sky_horizon_color = Color("3d5c67")
	sky_material.ground_bottom_color = Color("07141c")
	sky_material.ground_horizon_color = Color("3d5c67")
	sky_material.sky_curve = 0.22
	sky.sky_material = sky_material
	environment.sky = sky
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color("88a0ac")
	environment.ambient_light_energy = 0.40
	environment.fog_enabled = true
	environment.fog_light_color = Color("3c5965")
	environment.fog_light_energy = 0.62
	environment.fog_density = 0.0026
	environment.fog_sky_affect = 0.4
	environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	environment_node.environment = environment
	add_child(environment_node)
	var moon: DirectionalLight3D = DirectionalLight3D.new()
	moon.name = "StormLight"
	moon.rotation_degrees = Vector3(-38, -28, 0)
	moon.light_color = Color("b9c8d5")
	moon.light_energy = 0.60
	moon.shadow_enabled = true
	moon.directional_shadow_max_distance = 80.0
	add_child(moon)
	var sea_mesh: PlaneMesh = PlaneMesh.new()
	sea_mesh.size = Vector2(1600, 1600)
	sea_mesh.subdivide_width = 100
	sea_mesh.subdivide_depth = 100
	var sea: MeshInstance3D = MeshInstance3D.new()
	sea.name = "water"
	sea.mesh = sea_mesh
	sea.position.y = -132.0
	var water_material: ShaderMaterial = ShaderMaterial.new()
	water_material.shader = load("res://shaders/water.gdshader")
	sea.material_override = water_material
	add_child(sea)

func _build_city() -> void:
	var city: Node3D = Node3D.new()
	city.name = "NacreSubmergedCity"
	add_child(city)
	for index in range(42):
		var angle: float = rng.randf_range(0, TAU)
		var radius: float = rng.randf_range(60, 360)
		var height: float = rng.randf_range(4, 42)
		var width: float = rng.randf_range(7, 19)
		var center: Vector3 = Vector3(cos(angle) * radius, -132 + height * 0.5 - 2, sin(angle) * radius)
		var building: MeshInstance3D = _box(city, center, Vector3(width, height, width * 0.8), materials["dark"])
		building.rotation.z = rng.randf_range(-0.11, 0.11)
		_box(city, center + Vector3(0, height * 0.5, 0), Vector3(width + 0.4, 0.5, width * 0.8 + 0.4), materials["edge"])
		if index % 3 == 0:
			_box(city, center + Vector3(0, height * 0.5 + 1, 0), Vector3(width * 0.5, 2, width * 0.3), materials["metal"])
		for row in range(2):
			_box(city, center + Vector3(0, height * 0.2 - row * 5, width * 0.4 + 0.05), Vector3(width * 0.8, 1.1, 0.1), materials["window"])
	# Marina fragments and a collapsed skybridge barely clear the water.
	_box(city, Vector3(-45, -131, 35), Vector3(25, 0.6, 6), materials["wood"])
	var bridge: MeshInstance3D = _box(city, Vector3(44, -128, 22), Vector3(46, 2, 7), materials["concrete"])
	bridge.rotation.z = -0.22

func _build_twin_tower() -> void:
	var twin: Node3D = Node3D.new()
	twin.name = "HesperieLeaningTower"
	add_child(twin)
	twin.position = Vector3(41, -143, -25)
	twin.rotation_degrees.z = 10.0
	_box(twin, Vector3(0, 91, 0), Vector3(22, 182, 22), materials["window"])
	for level in range(31):
		var yy: float = level * 6.0
		_box(twin, Vector3(0, yy, 0), Vector3(23.2, 0.5, 23.2), materials["edge"])
		for side in [-1, 1]:
			_box(twin, Vector3(side * 11.1, yy + 2.8, 0), Vector3(0.2, 5.4, 0.3), materials["metal"])
			_box(twin, Vector3(0, yy + 2.8, side * 11.1), Vector3(0.3, 5.4, 0.2), materials["metal"])
		if level % 5 == 0:
			_box(twin, Vector3(0, yy + 3, 11.13), Vector3(15, 0.35, 0.2), materials["lit_amber"])
	_box(twin, Vector3(0, 184, 0), Vector3(12, 5, 12), materials["dark"])
	_label(twin, Vector3(0, 170, 11.3), "H E S P É R I E", 88, Color("b9c7cb"), 0.025, false)
	# The broken connection is a visual collision with Aube, never a physical player trap.
	var broken_bridge: MeshInstance3D = _box(self, Vector3(16, 24, -12), Vector3(17, 1.0, 5), materials["edge"])
	broken_bridge.rotation_degrees.z = 12
	for index in range(7):
		var beam: MeshInstance3D = _box(self, Vector3(14 + index * 0.8, 24 - index * 0.5, -12), Vector3(0.3, 6, 0.3), materials["metal"])
		beam.rotation_degrees = Vector3(index * 5, 0, -25 + index * 9)

func _build_lower_shell() -> void:
	var shell: Node3D = Node3D.new()
	shell.name = "UnplayableLowerTowerFacade"
	add_child(shell)
	_box(shell, Vector3(0, -69, 0), Vector3(23.8, 138, 23.8), materials["window"])
	for level in range(25):
		var yy: float = -138.0 + float(level) * 6
		_box(shell, Vector3(0, yy, 0), Vector3(24.5, 0.4, 24.5), materials["edge"])
	for xx in [-11.8, -6.0, 0.0, 6.0, 11.8]:
		_box(shell, Vector3(xx, -69, 12), Vector3(0.15, 138, 0.25), materials["metal"])
		_box(shell, Vector3(xx, -69, -12), Vector3(0.15, 138, 0.25), materials["metal"])

func _floor_surface(parent: Node3D, y: float, floor_material: Material) -> void:
	# Four slabs make the 5.4 m square shaft genuinely open at every level.
	_box(parent, Vector3(-7.35, y - 0.3, 0), Vector3(9.3, 0.6, 24), floor_material, true)
	_box(parent, Vector3(7.35, y - 0.3, 0), Vector3(9.3, 0.6, 24), floor_material, true)
	_box(parent, Vector3(0, y - 0.3, -7.35), Vector3(5.4, 0.6, 9.3), floor_material, true)
	_box(parent, Vector3(0, y - 0.3, 7.35), Vector3(5.4, 0.6, 9.3), floor_material, true)
	# A fixed amber strip identifies the entry lip; it remains clear of collisions.
	_box(parent, Vector3(2.76, y + 0.015, 0), Vector3(0.16, 0.025, 3.6), materials["lit_amber"])
	for xx in [-12.0, 12.0]:
		_box(parent, Vector3(xx, y + 0.55, 0), Vector3(0.28, 1.1, 24), materials["concrete"], true)
	for zz in [-12.0, 12.0]:
		_box(parent, Vector3(0, y + 0.55, zz), Vector3(24, 1.1, 0.28), materials["concrete"], true)
	for xx in [-11.6, 11.6]:
		for zz in [-11.6, -4.2, 4.2, 11.6]:
			_box(parent, Vector3(xx, y + 2.8, zz), Vector3(0.65, 5.6, 0.65), materials["edge"], true)
	for zz in [-11.6, 11.6]:
		for xx in [-4.2, 4.2]:
			_box(parent, Vector3(xx, y + 2.8, zz), Vector3(0.65, 5.6, 0.65), materials["edge"], true)
	# Intact pane fragments. Open gaps show the sea and the other tower.
	for zz in [-11.9, 11.9]:
		for xx in [-8.0, 0.0, 8.0]:
			if rng.randf() > 0.45:
				_box(parent, Vector3(xx, y + 2.65, zz), Vector3(3.9, 2.8, 0.07), materials["window"])
	for xx in [-11.9, 11.9]:
		for zz in [-8.0, 8.0]:
			if rng.randf() > 0.5:
				_box(parent, Vector3(xx, y + 2.65, zz), Vector3(0.07, 2.8, 3.9), materials["window"])

func _build_floor(number: int, spec: Dictionary) -> void:
	var floor_node: Node3D = Node3D.new()
	floor_node.name = "Floor%d" % number
	add_child(floor_node)
	var y: float = floor_heights[number]
	var floor_material: Material = materials["concrete"] if number <= 26 else materials["cream"]
	_floor_surface(floor_node, y, floor_material)
	var default_names: Dictionary = {30:"RESTAURANT PANORAMIQUE", 29:"SUITES DE L'AUBE", 28:"BUREAUX PELAGOS", 27:"JARDIN DES ENFANTS", 26:"SPA ET BASSIN", 25:"REFUGE TECHNIQUE"}
	var title: String = str(spec.get("name", default_names[number])).to_upper()
	_label(floor_node, Vector3(4.6, y + 3.8, -2.9), "%02d / %s" % [number, title], 40, Color("d7ded8"), 0.009, true)
	_label(floor_node, Vector3(-2.64, y + 1.7, 0), "%02d" % number, 92, Color("e8a15f"), 0.014, true)
	# Ceiling structural beams and soft indirect lights establish each volume.
	for zz in [-10.5, 10.5]:
		_box(floor_node, Vector3(0, y + 5.45, zz), Vector3(24, 0.3, 0.38), materials["metal"])
	for xx in [-7.3, 7.3]:
		_box(floor_node, Vector3(xx, y + 5.35, 0), Vector3(0.7, 0.12, 20), materials["dark"])
		_box(floor_node, Vector3(xx, y + 5.25, 0), Vector3(0.3, 0.08, 7), materials["lit_amber"] if number in [30,29] else materials["lit_blue"])
		_light(floor_node, Vector3(xx, y + 3.8, 0), Color("ecb778") if number in [30,29] else Color("6da1b3"), 0.95, 11)
	match number:
		30: _restaurant(floor_node, y)
		29: _hotel(floor_node, y)
		28: _offices(floor_node, y)
		27: _children(floor_node, y)
		26: _spa(floor_node, y)
		25: _maintenance(floor_node, y)
	_variant_module(floor_node, y, int(spec.get("layout_variant", 0)))
	var prop_rng: RandomNumberGenerator = RandomNumberGenerator.new()
	prop_rng.seed = int(spec.get("prop_seed", rng.randi()))
	for index in range(12):
		# Debris is small and never occupies the central cross or a rescue socket.
		var xx: float = prop_rng.randf_range(-10.5, 10.5)
		var zz: float = prop_rng.randf_range(-10.5, 10.5)
		if abs(xx) < 4.3 or abs(zz) < 3.0 or (xx > 4.5 and abs(abs(zz) - 6.0) < 2.0):
			continue
		var debris: MeshInstance3D = _box(floor_node, Vector3(xx, y + 0.09, zz), Vector3(prop_rng.randf_range(0.3, 0.9), 0.16, prop_rng.randf_range(0.2, 0.6)), materials["edge"])
		debris.rotation.y = prop_rng.randf_range(-PI, PI)
	var hazard: String = str(spec.get("hazard", "none"))
	floor_node.set_meta("hazard", hazard)
	if hazard == "smoke":
		for index in range(4):
			_sphere(floor_node, Vector3(-7 + index * 2.5, y + 3.4, -7), Vector3(5.0, 1.2, 4.0), materials["haze"])
		_light(floor_node, Vector3(-8, y + 1.4, -9), Color("ff8052"), 0.8, 5)
	if hazard == "water":
		_box(floor_node, Vector3(7, y + 0.025, 5), Vector3(7, 0.015, 9), materials["pool"])
	_make_beacon(floor_node, number, y)
	if bool(spec.get("survivor", number in [30,28,26])):
		var survivor_name: String = str(spec.get("survivor_name", {30:"Ana Rios",28:"Samuel Breton",26:"Nora Haddad"}.get(number,"Rescapé")))
		var survivor: Node3D = _interaction(floor_node, Vector3(7, y, -6), "survivor", "survivor_%d" % number, number, survivor_name, "Personne isolée. Stabilisez-la puis conduisez-la à la balise de treuil.")
		_human(survivor, Vector3.ZERO, materials["blue"] if number == 28 else materials["cream"], false)
		_label(survivor, Vector3(0, 2.25, 0), survivor_name, 30, Color("a9e5d6"), 0.008)
	if bool(spec.get("evidence", number in [29,27,26])):
		var evidence: Node3D = _interaction(floor_node, Vector3(7, y, 6), "evidence", "evidence_%d" % number, number, str(spec.get("evidence_title", "Archive SILLAGE")), str(spec.get("evidence_text", "Un enregistrement antérieur à la catastrophe mentionne des voix venant des fondations.")))
		_box(evidence, Vector3(0, 0.5, 0), Vector3(1.1, 1.0, 0.7), materials["dark"], true)
		_box(evidence, Vector3(0, 1.05, 0), Vector3(0.7, 0.07, 0.48), materials["lit_blue"])
		_label(evidence, Vector3(0, 1.65, 0), "ARCHIVE", 26, Color("a6d2e4"), 0.008)
	if bool(spec.get("supplies", number in [29,25])):
		var supply: Node3D = _interaction(floor_node, Vector3(-7, y, 6), "supply", "supply_%d" % number, number, "Caisse de secours", "Réserve de balises, ancrages et bouteilles d'air.")
		_supply_crate(supply, Vector3.ZERO)
	if number == 25:
		var refuge: Node3D = _interaction(floor_node, Vector3(7, y, 6), "refuge", "refuge_25", number, "Refuge 25", "Liaison sécurisée avec le toit. Sauvegarde et fin de la tranche de prototype.")
		_box(refuge, Vector3(0, 0.85, 0), Vector3(1.7, 1.7, 0.9), materials["metal"], true)
		_box(refuge, Vector3(0, 1.2, 0.49), Vector3(1.25, 0.55, 0.05), materials["lit_green"])
		_label(refuge, Vector3(0, 2.5, 0), "REFUGE 25\nLIAISON SÉCURISÉE", 36, Color("98efc9"), 0.01)
		_light(refuge, Vector3(0, 2.7, 0), Color("6eddb3"), 1.4, 9)

func _restaurant(parent: Node3D, y: float) -> void:
	for pos in [Vector3(-7,y,-7), Vector3(-7,y,7), Vector3(7,y,8)]:
		_cylinder(parent, pos + Vector3(0,1.0,0), 1.4, 0.12, materials["cream"], true)
		_cylinder(parent, pos + Vector3(0,0.5,0), 0.15, 0.9, materials["gold"])
		for offset in [Vector3(1.8,0,0), Vector3(-1.8,0,0)]:
			_chair(parent, pos + offset, 0, materials["red"])
		_cylinder(parent, pos + Vector3(0,1.2,0), 0.06, 0.3, materials["lit_amber"])
	_box(parent, Vector3(-7,y+0.7,-10.5), Vector3(8,1.4,1.5), materials["wood"], true)
	_box(parent, Vector3(-7,y+1.45,-10.5), Vector3(8.4,0.1,1.7), materials["gold"])
	for index in range(8):
		_cylinder(parent, Vector3(-10 + index * 0.8,y+1.7,-10.5), 0.1, 0.43, materials["green"])
	_label(parent, Vector3(-7,y+3.5,-11.5), "LE BELVÉDÈRE", 74, Color("e3bd83"), 0.017, false)
	_planter(parent, Vector3(10,y,-9))
	_planter(parent, Vector3(10,y,9))

func _hotel(parent: Node3D, y: float) -> void:
	for pos in [Vector3(-7,y,-7),Vector3(8,y,-8)]:
		_box(parent, pos + Vector3(0,0.35,0), Vector3(3.2,0.7,3.9), materials["wood"], true)
		_box(parent, pos + Vector3(0,0.8,0), Vector3(3.1,0.28,3.8), materials["cream"])
		_box(parent, pos + Vector3(0,1.0,-1.3), Vector3(2.5,0.22,0.6), materials["white"])
		_box(parent, pos + Vector3(0,1.15,0.7), Vector3(3.2,0.1,1.4), materials["blue"])
		_box(parent, pos + Vector3(0,1.2,-2), Vector3(3.4,1.8,0.25), materials["wood"], true)
	_box(parent, Vector3(-4.2,y+1.8,-7.5), Vector3(0.25,3.6,7), materials["wood"], true)
	# Two partition pieces leave a two-metre doorway to the west supply room.
	_box(parent, Vector3(-9.5,y+1.8,3.7), Vector3(3,3.6,0.25), materials["wood"], true)
	_box(parent, Vector3(-5,y+1.8,3.7), Vector3(2,3.6,0.25), materials["wood"], true)
	_label(parent, Vector3(6,y+3.0,-10.8), "SUITE 2908", 48, Color("d3bc91"), 0.01, false)
	_box(parent, Vector3(10,y+0.35,4), Vector3(1.1,0.7,0.8), materials["red"], true)

func _offices(parent: Node3D, y: float) -> void:
	for pos in [Vector3(-8,y,-8),Vector3(-5,y,-8),Vector3(-8,y,7),Vector3(8,y,8)]:
		_box(parent, pos + Vector3(0,0.83,0), Vector3(2.3,0.15,1.5), materials["wood"], true)
		for offset in [-0.9,0.9]:
			_box(parent, pos + Vector3(offset,0.4,0), Vector3(0.12,0.8,1.2), materials["metal"])
		_box(parent, pos + Vector3(0,1.3,-0.35), Vector3(1.0,0.65,0.08), materials["dark"])
		_box(parent, pos + Vector3(0,1.3,-0.29), Vector3(0.9,0.55,0.04), materials["screen"])
		_chair(parent, pos + Vector3(0,0,1.3), 0, materials["dark"])
	for xx in [-10.7,-9.4,-8.1]:
		_box(parent, Vector3(xx,y+1.3,10.6), Vector3(1.15,2.6,0.8), materials["metal"], true)
		for yy in [0.5,1.2,1.9]:
			_box(parent, Vector3(xx,y+yy,11.03), Vector3(0.8,0.05,0.06), materials["gold"])
	_label(parent, Vector3(4.2,y+3.4,-10.8), "PELAGOS\nDivision des fondations", 48, Color("b5d2d4"), 0.012, false)

func _children(parent: Node3D, y: float) -> void:
	for index in range(6):
		var xx: float = -10.1 + index * 1.05
		var color_mat: Material = [materials["red"],materials["yellow"],materials["blue"]][index % 3]
		_box(parent, Vector3(xx,y+0.8,-10), Vector3(0.95,1.6,0.7), color_mat, true)
		_box(parent, Vector3(xx,y+1.1,-9.6), Vector3(0.65,0.55,0.06), materials["dark"])
	for pos in [Vector3(-7,y,-6),Vector3(-7,y,7)]:
		_cylinder(parent, pos + Vector3(0,0.55,0), 1.3, 0.15, materials["yellow"], true)
		for offset in [Vector3(1.6,0,0),Vector3(-1.6,0,0)]:
			_box(parent, pos + offset + Vector3(0,0.3,0), Vector3(0.7,0.6,0.7), materials["blue"], true)
	for index in range(7):
		var toy: MeshInstance3D = _box(parent, Vector3(8 + rng.randf_range(-1,1),y+0.2,-8 + rng.randf_range(-1,1)), Vector3(0.4,0.4,0.4), materials["red"] if index % 2 else materials["blue"])
		toy.rotation.y = rng.randf_range(0,PI)
	_label(parent, Vector3(-7,y+3.3,-11.4), "LE JARDIN DES MARÉES", 50, Color("dcc88d"), 0.012, false)
	_box(parent, Vector3(10.9,y+2.0,6), Vector3(0.05,1.6,3.6), materials["cream"])
	# Child-made drawn towers as code-native geometry on the notice board.
	for zz in [5.4,6.4]:
		_box(parent, Vector3(10.86,y+2.0,zz), Vector3(0.04,1.2,0.45), materials["blue"])

func _spa(parent: Node3D, y: float) -> void:
	_box(parent, Vector3(-7,y+0.15,-6.8), Vector3(7,0.3,6.5), materials["edge"], true)
	_box(parent, Vector3(-7,y+0.32,-6.8), Vector3(6.6,0.04,6.1), materials["pool"])
	for pos in [Vector3(-8,y,7),Vector3(-5,y,7),Vector3(9,y,-9)]:
		_box(parent, pos + Vector3(0,0.45,0), Vector3(1.6,0.3,3.4), materials["cream"], true)
		var back: MeshInstance3D = _box(parent, pos + Vector3(0,0.9,-1.3), Vector3(1.6,1.2,0.22), materials["wood"])
		back.rotation.x = -0.3
	for xx in [-10.8,-10.1]:
		_cylinder(parent, Vector3(xx,y+2.4,2), 0.15, 4.8, materials["metal"])
	_label(parent, Vector3(-7,y+3.6,-11.5), "LES BAINS SUSPENDUS", 62, Color("a5d8d6"), 0.015, false)
	_light(parent, Vector3(-7,y+0.8,-6.8), Color("28a7a6"), 1.6, 7)

func _maintenance(parent: Node3D, y: float) -> void:
	for xx in [-10.7,-9.6,-8.5]:
		_box(parent, Vector3(xx,y+1.2,-9.5), Vector3(0.85,2.4,1.4), materials["metal"], true)
		_box(parent, Vector3(xx,y+1.7,-8.76), Vector3(0.4,0.4,0.05), materials["screen"])
	for xx in [-9,-7,-5]:
		_cylinder(parent, Vector3(xx,y+0.9,8), 0.25, 1.7, materials["orange"])
	_box(parent, Vector3(8,y+0.45,-8), Vector3(4.4,0.35,1.7), materials["green"], true)
	_box(parent, Vector3(8,y+0.72,-8), Vector3(4.2,0.2,1.5), materials["cream"])
	for zz in [-10.7,10.7]:
		var pipe: MeshInstance3D = _cylinder(parent, Vector3(0,y+4.6,zz), 0.19, 23, materials["yellow"])
		pipe.rotation.z = PI * 0.5
	_label(parent, Vector3(0,y+3.5,-11.5), "REFUGE 25\nSECTEUR SÉCURISÉ", 66, Color("b1e6c4"), 0.016, false)
	_human(parent, Vector3(9,y,2.5), materials["orange"], true)
	for xx in range(-11,12):
		_box(parent, Vector3(xx,y+0.015,3.3), Vector3(0.45,0.03,0.12), materials["yellow"])

func _make_beacon(parent: Node3D, number: int, y: float) -> void:
	var beacon: Node3D = _interaction(parent, Vector3(3.6,y,0), "beacon", "beacon_%d" % number, number, "Balise de treuil", "Point de raccordement au rappel et d'évacuation des rescapés vers le toit.")
	_cylinder(beacon, Vector3(0,0.18,0), 0.34, 0.36, materials["metal"])
	_cylinder(beacon, Vector3(0,0.9,0), 0.06, 1.3, materials["orange"])
	_sphere(beacon, Vector3(0,1.6,0), Vector3(0.18,0.18,0.18), materials["lit_green"])
	_label(beacon, Vector3(0,2.2,0), "TREUIL", 26, Color("99e6cc"), 0.007)

func _variant_module(parent: Node3D, y: float, variant: int) -> void:
	# A bounded west-side pocket changes layout without moving protected sockets.
	var module: Node3D = Node3D.new()
	module.name = "LayoutVariant%d" % variant
	parent.add_child(module)
	module.position = Vector3(-10.3,y,0)
	match variant:
		0:
			_box(module,Vector3(0,0.45,0),Vector3(1.0,0.9,2.7),materials["wood"],true)
			_box(module,Vector3(-0.4,1.05,0),Vector3(0.2,1.1,2.7),materials["cream"],true)
		1:
			for zz in [-1.0,1.0]:
				_cylinder(module,Vector3(0,0.75,zz),0.45,1.5,materials["edge"],true)
				_sphere(module,Vector3(0,1.8,zz),Vector3(0.4,0.5,0.4),materials["gold"])
		2:
			var panel: MeshInstance3D = _box(module,Vector3(0,0.4,0),Vector3(1.0,0.2,2.4),materials["metal"],true)
			panel.rotation_degrees.z = 22.0
			_box(module,Vector3(0,1.5,-1.5),Vector3(0.25,3.0,0.3),materials["metal"])

func _build_roof() -> Dictionary:
	var roof: Node3D = Node3D.new()
	roof.name = "RoofCommandPost"
	add_child(roof)
	_floor_surface(roof,42,materials["concrete"])
	# Heliport markings are physical painted strips, not a flat menu background.
	for xx in [-7.8,-4.2]:
		_box(roof,Vector3(xx,42.025,-6),Vector3(0.25,0.03,4.5),materials["white"])
	_box(roof,Vector3(-6,42.025,-6),Vector3(3.7,0.03,0.25),materials["white"])
	for xx in [-10.4,-1.6]:
		_box(roof,Vector3(xx,42.03,-6),Vector3(0.12,0.04,9.0),materials["yellow"])
	for zz in [-10.4,-1.6]:
		_box(roof,Vector3(-6,42.03,zz),Vector3(9.0,0.04,0.12),materials["yellow"])
	var helicopter: Node3D = Node3D.new()
	helicopter.name = "RescueHelicopter"
	roof.add_child(helicopter)
	helicopter.position = Vector3(-6,43.35,-6)
	_sphere(helicopter,Vector3(0,0.9,0),Vector3(1.3,1.25,2.4),materials["orange"])
	_sphere(helicopter,Vector3(0,1.1,-1.5),Vector3(1.15,0.8,1.2),materials["window"])
	_box(helicopter,Vector3(0,1.1,3.0),Vector3(0.38,0.45,4.2),materials["orange"])
	_box(helicopter,Vector3(0,1.6,4.7),Vector3(0.12,1.8,1.4),materials["orange"])
	for xx in [-1.2,1.2]:
		_box(helicopter,Vector3(xx,-0.35,0),Vector3(0.15,0.18,4.5),materials["metal"])
		for zz in [-1,1]:
			_box(helicopter,Vector3(xx,-0.1,zz),Vector3(0.14,0.8,0.14),materials["metal"])
	_cylinder(helicopter,Vector3(0,2.0,0),0.14,1.0,materials["metal"])
	var rotor: Node3D = Node3D.new()
	rotor.name = "Rotor"
	helicopter.add_child(rotor)
	rotor.position.y = 2.6
	_box(rotor,Vector3.ZERO,Vector3(11,0.08,0.3),materials["dark"])
	_box(rotor,Vector3.ZERO,Vector3(0.3,0.08,11),materials["dark"])
	_sphere(helicopter,Vector3(0,1.8,4.6),Vector3(0.12,0.12,0.12),materials["lit_red"])
	_light(helicopter,Vector3(0,-0.4,-1.5),Color("ffbe7c"),1.5,8)
	_label(helicopter,Vector3(1.33,1.0,0),"SECOURS",28,Color.WHITE,0.007,true)
	_human(roof,Vector3(6.6,42,-7),materials["orange"],true)
	_human(roof,Vector3(9,42,-6),materials["blue"],true)
	_human(roof,Vector3(7,42,4.7),materials["orange"],true)
	_label(roof,Vector3(7,44.3,4.7),"CPT. VARGA",30,Color("eab686"),0.004)
	_supply_crate(roof,Vector3(-7,42,7))
	_supply_crate(roof,Vector3(-9,42,7))
	_box(roof,Vector3(8,42.9,8.7),Vector3(4,1.8,1.8),materials["metal"],true)
	_box(roof,Vector3(8,43.9,8.7),Vector3(4.3,0.16,2.1),materials["dark"])
	_cylinder(roof,Vector3(10,45,10),0.08,6,materials["metal"])
	_box(roof,Vector3(10,47.4,10),Vector3(2.0,0.12,0.12),materials["metal"])
	_sphere(roof,Vector3(10,48.1,10),Vector3(0.15,0.15,0.15),materials["lit_red"])
	# The rope anchor crosses the opening 3 m above the roof.
	_box(roof,Vector3(0,45,0),Vector3(7.0,0.22,0.22),materials["metal"])
	for xx in [-3.4,3.4]:
		_box(roof,Vector3(xx,43.5,0),Vector3(0.18,3,0.18),materials["orange"])
	_make_beacon(roof,31,42)
	_label(roof,Vector3(4.2,44.6,-2.8),"AUBE / TOIT\nPOINT DE DESCENTE",45,Color("efd4ab"),0.010,true)
	_label(roof,Vector3(0,44.0,11.3),"ORPHÉE\nPOSTE DE SECOURS",66,Color("cedbd6"),0.014,false)
	for pos in [Vector3(8,45,-6),Vector3(-7,45,7)]:
		_light(roof,pos,Color("eabb83"),1.6,13)
	return {"helicopter":helicopter,"rotor":rotor}

func _build_rain() -> void:
	rain = MultiMeshInstance3D.new()
	rain.name = "Rain"
	var multi: MultiMesh = MultiMesh.new()
	multi.transform_format = MultiMesh.TRANSFORM_3D
	var mesh: BoxMesh = BoxMesh.new()
	mesh.size = Vector3(0.012,0.55,0.012)
	mesh.material = materials["rain"]
	multi.mesh = mesh
	multi.instance_count = 420
	for index in range(420):
		var transform: Transform3D = Transform3D(Basis(Vector3.FORWARD,0.18),Vector3(rng.randf_range(-36,36),rng.randf_range(0,62),rng.randf_range(-36,36)))
		multi.set_instance_transform(index,transform)
	rain.multimesh = multi
	rain.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(rain)
	rain_origin = Vector3(0,12,0)
	rain.position = rain_origin

func create_shadow(number: int) -> Node3D:
	var shadow: Node3D = Node3D.new()
	shadow.name = "SillageFigure%d" % number
	add_child(shadow)
	shadow.position = Vector3(-6,float(number-24)*6,-3.8)
	_human(shadow,Vector3.ZERO,materials["dark"],false)
	shadow.scale = Vector3(0.72,1.4,0.72)
	_sphere(shadow,Vector3(-0.09,1.65,-0.18),Vector3(0.025,0.025,0.025),materials["lit_amber"])
	_sphere(shadow,Vector3(0.09,1.65,-0.18),Vector3(0.025,0.025,0.025),materials["lit_amber"])
	shadow.visible = false
	return shadow

func _interaction(parent: Node3D, pos: Vector3, kind: String, id_value: String, number: int, title: String, description: String) -> Node3D:
	var node: Node3D = Node3D.new()
	node.name = id_value
	parent.add_child(node)
	node.position = pos
	node.set_meta("kind",kind)
	node.set_meta("id",id_value)
	node.set_meta("floor",number)
	node.set_meta("title",title)
	node.set_meta("description",description)
	interactables.append(node)
	return node

func _human(parent: Node3D, pos: Vector3, clothing: Material, helmet: bool) -> Node3D:
	var person: Node3D = Node3D.new()
	parent.add_child(person)
	person.position = pos
	_box(person,Vector3(0,1.05,0),Vector3(0.48,0.58,0.3),clothing)
	for xx in [-0.14,0.14]:
		_box(person,Vector3(xx,0.43,0),Vector3(0.17,0.72,0.22),materials["dark"])
		_box(person,Vector3(xx,0.08,-0.08),Vector3(0.22,0.16,0.38),materials["black_metal"])
	for xx in [-0.33,0.33]:
		var arm: MeshInstance3D = _box(person,Vector3(xx,0.98,0),Vector3(0.14,0.6,0.18),clothing)
		arm.rotation.z = 0.08 if xx < 0 else -0.08
		_sphere(person,Vector3(xx,0.65,-0.01),Vector3(0.09,0.11,0.08),materials["skin"])
	_sphere(person,Vector3(0,1.61,0),Vector3(0.21,0.27,0.21),materials["skin"])
	if helmet:
		_sphere(person,Vector3(0,1.79,0),Vector3(0.25,0.15,0.25),materials["white"])
		_box(person,Vector3(0,1.0,-0.16),Vector3(0.44,0.08,0.02),materials["yellow"])
		_box(person,Vector3(0,1.2,-0.16),Vector3(0.44,0.08,0.02),materials["yellow"])
		_box(person,Vector3(0,1.25,0.24),Vector3(0.38,0.65,0.25),materials["orange"])
	else:
		_sphere(person,Vector3(0,1.76,0.05),Vector3(0.215,0.12,0.21),materials["wood"])
	return person

func _supply_crate(parent: Node3D, pos: Vector3) -> void:
	_box(parent,pos+Vector3(0,0.38,0),Vector3(1.5,0.76,1.0),materials["orange"],true)
	_box(parent,pos+Vector3(0,0.81,0),Vector3(1.6,0.1,1.1),materials["dark"])
	_box(parent,pos+Vector3(0,0.43,0.515),Vector3(0.12,0.43,0.02),materials["white"])
	_box(parent,pos+Vector3(0,0.43,0.52),Vector3(0.43,0.12,0.02),materials["white"])
	_label(parent,pos+Vector3(0,1.5,0),"SECOURS",26,Color("f3c184"),0.008)

func _chair(parent: Node3D, pos: Vector3, yaw: float, mat: Material) -> void:
	var chair: Node3D = Node3D.new()
	parent.add_child(chair)
	chair.position = pos
	chair.rotation.y = yaw
	_box(chair,Vector3(0,0.5,0),Vector3(0.75,0.15,0.8),mat,true)
	_box(chair,Vector3(0,0.95,0.34),Vector3(0.75,0.8,0.15),mat,true)
	for xx in [-0.27,0.27]:
		for zz in [-0.27,0.27]:
			_box(chair,Vector3(xx,0.25,zz),Vector3(0.07,0.5,0.07),materials["metal"])

func _planter(parent: Node3D, pos: Vector3) -> void:
	_cylinder(parent,pos+Vector3(0,0.35,0),0.5,0.7,materials["wood"],true)
	_cylinder(parent,pos+Vector3(0,1.2,0),0.08,1.6,materials["wood"])
	_sphere(parent,pos+Vector3(0,1.9,0),Vector3(0.85,1.0,0.85),materials["green"])

func _box(parent: Node3D, pos: Vector3, size_value: Vector3, material: Material, solid: bool = false) -> MeshInstance3D:
	var node: MeshInstance3D = MeshInstance3D.new()
	var mesh: BoxMesh = BoxMesh.new()
	mesh.size = size_value
	node.mesh = mesh
	node.material_override = material
	parent.add_child(node)
	node.position = pos
	if solid:
		var body: StaticBody3D = StaticBody3D.new()
		var collider: CollisionShape3D = CollisionShape3D.new()
		var shape: BoxShape3D = BoxShape3D.new()
		shape.size = size_value
		collider.shape = shape
		body.add_child(collider)
		node.add_child(body)
	return node

func _cylinder(parent: Node3D, pos: Vector3, radius: float, height: float, material: Material, solid: bool = false) -> MeshInstance3D:
	var node: MeshInstance3D = MeshInstance3D.new()
	var mesh: CylinderMesh = CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	mesh.radial_segments = 12
	node.mesh = mesh
	node.material_override = material
	parent.add_child(node)
	node.position = pos
	if solid:
		var body: StaticBody3D = StaticBody3D.new()
		var collider: CollisionShape3D = CollisionShape3D.new()
		var shape: CylinderShape3D = CylinderShape3D.new()
		shape.radius = radius
		shape.height = height
		collider.shape = shape
		body.add_child(collider)
		node.add_child(body)
	return node

func _sphere(parent: Node3D, pos: Vector3, scale_value: Vector3, material: Material) -> MeshInstance3D:
	var node: MeshInstance3D = MeshInstance3D.new()
	var mesh: SphereMesh = SphereMesh.new()
	mesh.radius = 1.0
	mesh.height = 2.0
	mesh.radial_segments = 12
	mesh.rings = 6
	node.mesh = mesh
	node.material_override = material
	parent.add_child(node)
	node.position = pos
	node.scale = scale_value
	return node

func _label(parent: Node3D, pos: Vector3, text_value: String, font_size: int, color: Color, pixel_size: float = 0.01, billboard: bool = true) -> Label3D:
	var label: Label3D = Label3D.new()
	label.text = text_value
	label.font_size = font_size
	label.pixel_size = pixel_size
	label.modulate = color
	label.outline_modulate = Color("0c1c24")
	label.outline_size = 6
	label.no_depth_test = false
	if billboard:
		label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	parent.add_child(label)
	label.position = pos
	return label

func _light(parent: Node3D, pos: Vector3, color: Color, energy: float, light_range: float) -> OmniLight3D:
	var light: OmniLight3D = OmniLight3D.new()
	light.light_color = color
	light.light_energy = energy
	light.omni_range = light_range
	light.omni_attenuation = 1.3
	light.shadow_enabled = false
	parent.add_child(light)
	light.position = pos
	return light
