# État de livraison — version 0.1

**Date : 24 novembre 2026.** Cette livraison fournit un prototype jouable et une proposition de campagne complète. Les documents de conception décrivent volontairement davantage de contenu que ce qui est codé.

## Ce qui est livré

| Élément | État réel |
| --- | --- |
| Bible et catalogue | Univers original, personnages, intrigue, quatre fins, trente étages, tour Hespérie, souterrains, bunker, niveau 666 et extension Mountain Hole décrits |
| Document Word | Bible, catalogue et spécifications techniques réunis ; fabrication reproductible avec `tools/build_bible.py` |
| Prototype | Godot 4.7.2, solo, vue subjective, toit et étages 30 à 25 |
| Boucle de mission | Trois victimes à retrouver, transport abstrait au harnais, treuillage visible et confirmation, refuge final |
| Exploration | Trois indices, deux caisses, radio, journal, dangers et dispositions variant selon la graine |
| Rappel | Déplacement guidé dans le puits, balancement amorti, remontée, sortie aux paliers et ancrage secondaire consommable |
| Horreur | Silhouette au spa, dialogue radio ambigu, stress, lampe pour ralentir la silhouette et fusées pour la repousser |
| Persistance | Checkpoint local JSON validé, remplacement atomique et refus des données corrompues |
| Confort | Pause, sous-titres, mouvement de caméra réduit par défaut, éclairages intermittents facultatifs, son désactivable |
| Windows | Exécutable x64 exporté avec ressources embarquées, fourni en ZIP |
| Web | Export sans threads, rendu Compatibility, distribué par HTTP(S) ; WebAssembly et WebGL 2 nécessaires |

## Vérifications exécutées

Les quatre suites suivantes ont été exécutées avec succès sur les sources de cette livraison, sous Godot 4.7.2 : **1 184 contrôles au total**. Il s’agit de contrôles automatisés, pas de 1 184 parties humaines.

| Suite | Contrôles | Ce qu’elle vérifie |
| --- | ---: | --- |
| Génération | 820 | 200 graines, déterminisme, indépendance des tirages, invariants, couverture des variantes et rejet de définitions invalides |
| Sauvegarde | 80 | Aller-retour des données, écriture atomique, absence de mutation, schéma strict, bornes, doublons et données corrompues |
| Mission | 79 | Rappel, trois indices, trois sauvetages confirmés, caisses utilisables une fois, pause, checkpoints et condition de fin |
| Trajets physiques | 205 | 150 segments avec `move_and_slide`, 27 approches d’objectifs et retours, trois graines couvrant les trois dispositions de chaque étage |

Les tests de mission déplacent directement le joueur pour isoler les règles de jeu. Les tests de trajets vérifient séparément le déplacement réel avec la capsule et les collisions ; ils ne démontrent pas toutes les trajectoires libres possibles ni l’équilibre du jeu.

Un contrôle visuel natif a également permis d’ouvrir le menu, de commencer une intervention, de se déplacer sur le toit, de s’attacher à la corde, de descendre jusqu’au restaurant et d’ouvrir la pause. Il ne constitue pas un parcours humain complet des six étages.

Les exports **Windows Desktop** et **Web** ont terminé avec un code de sortie 0. Le binaire Windows est un PE32+ x86-64. L’environnement de fabrication étant Linux, cet exécutable n’a pas été lancé sous Windows. Les archives sont accompagnées de sommes SHA256.

Le navigateur de contrôle de cet environnement ne fournit pas WebGL 2 : la page de lancement s’affiche, mais le rendu 3D Web ne peut pas y démarrer. Cette restriction du navigateur de contrôle ne remplace pas un essai sur les navigateurs des joueurs. Le jeu a été exécuté dans Godot en mode graphique natif.

## Limites connues

- La campagne complète, Alma, la chute dans la piscine, Hespérie, les cavernes, le bunker et les fins sont conçus, mais non jouables dans cette version.
- Aucun multijoueur ni portage Unreal Engine 5 n’est inclus. Le document de portage est une proposition d’architecture.
- Le rappel est un contrôleur guidé ; il ne simule pas une corde articulée, les frottements ou une chaîne d’assurage réaliste.
- Les victimes utilisent des silhouettes géométriques. Le portage est abstrait ; l’animation complète et l’IA d’escorte restent à développer.
- S’accroupir réduit la caméra et la vitesse, sans raccourcir la capsule de collision.
- Les dégâts du bâtiment et l’eau reposent sur des géométries et événements préparés ; il n’y a pas de destruction structurelle ou de fluide intégralement simulé.
- Les mouvements de l’entité sont locaux au spa ; le jeu ne possède pas encore le directeur d’horreur complet décrit dans la bible.
- Les interfaces sont françaises. Il n’y a pas de doublage, de manette configurée ni de remappage complet des commandes.
- Les durées proposées dans la bible sont des objectifs de conception. Aucun test joueur ne confirme encore la durée, la difficulté ou la performance sur une configuration minimale.

## Prochain jalon recommandé

Faire essayer cette intervention de six étages, observer l’orientation autour du puits et le temps de retour des victimes, puis renforcer une tranche de trois étages avec de véritables assets, animations et sons. La migration vers UE5 doit commencer après validation de cette boucle, en conservant les règles de génération, les identifiants et les invariants documentés.

Les commandes de vérification se trouvent dans le README. Les détails de distribution et de provenance des modèles d’export se trouvent dans `EXPORTS.md`.
