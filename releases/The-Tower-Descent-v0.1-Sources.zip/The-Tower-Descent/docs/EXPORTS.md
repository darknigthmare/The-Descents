# Exports du prototype

Les presets se trouvent dans `prototype/export_presets.cfg`. Les deux commandes suivantes ont terminé avec un code de sortie 0 sous Godot 4.7.2 :

```bash
godot --headless --path prototype --export-release "Windows Desktop"
godot --headless --path prototype --export-release "Web"
```

Créer préalablement les dossiers `builds/windows` et `builds/web`. Relancer les exports après toute modification des sources ; un ancien binaire ne reflète pas automatiquement le nouvel état du dépôt.

## Résultats

| Cible | Résultat | Vérification disponible |
| --- | --- | --- |
| Windows x64 | `builds/windows/TheTowerDescent.exe`, ressources embarquées | Export terminé ; format PE32+ x86-64 identifié ; exécution sous Windows non testée |
| Web | `builds/web/index.html` et fichiers associés, copiés dans `dist/` | Export sans threads terminé ; page servie, rendu 3D bloqué dans le navigateur de contrôle qui ne fournit pas WebGL 2 |

Le dossier Web doit être servi par HTTP ou HTTPS avec ses fichiers `.wasm`, `.pck` et JavaScript ; ouvrir directement le HTML en `file://` ne constitue pas une installation correcte. L'export utilise le rendu Compatibility. Les exigences WebAssembly et WebGL 2 sont décrites dans la [documentation officielle Godot](https://docs.godotengine.org/en/stable/tutorials/export/exporting_for_web.html).

## Provenance des modèles d export

Source : [archive officielle Godot 4.7.2](https://github.com/godotengine/godot-builds/releases/download/4.7.2-stable/Godot_v4.7.2-stable_export_templates.tpz).

Seules les entrées `version.txt`, `web_nothreads_release.zip` et `windows_release_x86_64.exe` ont été extraites par requêtes HTTP Range avec réponses 206. Les tailles décompressées et les CRC32 ont été comparés au répertoire central du ZIP. L'archive complète de 1,28 Go n'a pas été téléchargée ; son SHA256 global n'a donc pas été vérifié.

Les modèles sont installés localement sous `~/.local/share/godot/export_templates/4.7.2.stable/`. Ils ne font pas partie des sources du jeu. Pour distribuer la version Windows, compresser l'exécutable dans un ZIP ; sa taille brute dépasse 100 Mio.
