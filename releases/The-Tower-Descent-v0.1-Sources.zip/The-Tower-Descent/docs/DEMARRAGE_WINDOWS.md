# The Tower Descent — prototype 0.1

## Lancer l’intervention

1. Extraire tout le ZIP dans un dossier.
2. Ouvrir **TheTowerDescent.exe**. Aucune installation de Godot n’est nécessaire.
3. Cliquer sur **Commencer l’intervention**. La graine proposée convient pour une première partie.

Vous êtes sur le toit de la tour Aube. Rejoignez la balise orange au bord du puits, appuyez sur **E**, puis descendez avec **S**. À hauteur d’une dalle, **E** vous fait quitter le rappel.

## Objectif

Retrouvez les trois personnes aux étages **30, 28 et 26**. Appuyez sur **E** à proximité pour les prendre en charge, puis revenez à la balise de l’étage et utilisez **E** pour lancer le treuil. Attendez la confirmation du toit. Après trois sauvetages, rejoignez le refuge de l’étage **25** et activez son relais.

Les lueurs bleues signalent les indices ; les caisses fournissent du matériel. Dans le spa, la lampe ralentit la silhouette et une fusée la repousse pendant vingt secondes.

## Commandes essentielles

| Action | Touche |
| --- | --- |
| Déplacement | ZQSD ou WASD |
| Regard | Souris ou flèches |
| Interaction | E |
| Descendre / remonter sur corde | S / Z ou W |
| Ancrage secondaire sur corde | X |
| Lampe / fusée | F / G |
| Radio / journal | R / J |
| Courir / s’accroupir / sauter | Maj / Ctrl / Espace |
| Pause et options | Échap |

Une sauvegarde locale est créée au départ et après les treuillages confirmés. **Commencer l’intervention** crée un nouveau checkpoint ; **Reprendre le dernier point sûr** poursuit le précédent. Les données ne sont pas envoyées en ligne.

## Portée de cette version

Prototype solo de six étages en géométrie simplifiée. La campagne complète est décrite dans la bible. Ce binaire a été exporté avec succès depuis Godot 4.7.2 ; son exécution sur un PC Windows reste à vérifier.

[Projet, sources et bible sur GitHub](https://github.com/darknigthmare/The-Descents/tree/feat/tower-descent-prototype-bible)

Les licences du moteur et de ses composants sont jointes dans `GODOT_LICENSES.txt`.
