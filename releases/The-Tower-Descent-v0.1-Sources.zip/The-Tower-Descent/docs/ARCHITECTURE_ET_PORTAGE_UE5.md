# Architecture du prototype et portage vers Unreal Engine 5

Version de conception 0.1 — 24 novembre 2026

Ce document explique le fonctionnement du prototype livré et propose une trajectoire vers Unreal Engine 5. Le prototype est un jeu solo Godot en vue subjective : toit, six étages de 30 à 25, trois sauvetages, trois indices et un refuge final. La campagne complète décrite dans la bible reste à produire.

Le moteur disponible et utilisé pour les vérifications est **Godot 4.7.2**. Le projet déclare une base de fonctionnalités 4.7 ; les versions antérieures n'ont pas été testées. Unreal Engine et Unity n'ont pas été exécutés. Des exports Windows x64 et Web ont été produits ; l'exécution sous Windows n'a pas été testée. La coopération en réseau n'est pas implémentée.

## Architecture actuellement présente

La scène d'entrée `prototype/scenes/main.tscn` instancie le contrôleur principal. Celui-ci construit le monde à partir d'une graine, ajoute le personnage, puis relie l'interface et les interactions. La géométrie est créée par code, sans dépendance à des modèles achetés ou à un service distant.

| Fichier dans prototype/scripts | Responsabilité réelle |
| --- | --- |
| `main.gd` | Cycle menu et partie, objectifs, interactions, ressources, événements, treuillage, points de reprise et coordination des autres scripts |
| `player_controller.gd` | `CharacterBody3D`, caméra, marche, course, saut, déplacement lent accroupi, rappel guidé, lampe et tracé de corde |
| `floor_generator.gd` | Production déterministe des six descriptions d'étage et validation des invariants de contenu |
| `world_builder.gd` | Géométrie, collisions, matériaux, mobilier, personnages simplifiés, signalétique, mer, ville, autre tour et points interactifs |
| `save_store.gd` | Validation et lecture des données JSON, écriture temporaire puis remplacement du point de reprise |
| `hud.gd` | Menu, jauges, objectifs, commandes contextuelles, radio, journal, pause et bilan |

Le personnage utilise `move_and_slide()` pour la marche. Godot décrit `CharacterBody3D` comme un corps contrôlé par script disposant notamment de détection des murs et des pentes ; la gravité et les règles de déplacement restent ici écrites dans le contrôleur. [Documentation Godot CharacterBody3D](https://docs.godotengine.org/en/stable/classes/class_characterbody3d.html)

`main.gd` est volontairement central pour cette tranche courte. Avant d'étendre la campagne, séparer ses responsabilités en gestion de mission, ressources, interactions, événements et sauvegarde évitera que chaque nouveau niveau ajoute des conditions dans une boucle unique.

## Espace et limites de la simulation

Le monde utilise le mètre. Une dalle jouable se trouve à `y = (numéro − 24) × 6` ; le toit est à 42 m dans le repère local. La mer est à −132 m. Cette origine permet de travailler sur les niveaux supérieurs tout en conservant une façade de gratte-ciel jusqu'au niveau de l'eau.

Chaque plateau mesure 24 m de côté et laisse un puits central de 5,4 m. Les points d'entrée de corde, de secours et de collecte occupent des emplacements protégés. Les variantes déplacent une portion de mobilier et la décoration sans déplacer les éléments nécessaires à l'objectif. Il existe donc une variation procédurale contrainte, pas encore une génération complète de plans architecturaux.

Le rappel actuel guide directement la position dans le puits, ajoute une oscillation latérale et affiche une ligne. L'ancrage secondaire amortit le balancement pendant une durée limitée. Ce dispositif n'est pas une simulation de corde segmentée ni un calcul d'efforts d'un système de sauvetage.

Le sauvetage est également simplifié : sécuriser le rescapé ralentit le joueur ; rejoindre la balise déclenche sa remontée animée. Il n'existe pas encore de navigation autonome de blessés, d'animation de portage complète ou de partage de charge entre deux équipiers. L'accroupissement abaisse la caméra et réduit la vitesse, mais ne réduit pas actuellement la capsule de collision.

## Génération déterministe et persistance

Le générateur conserve les fonctions architecturales et les objectifs : restaurant 30, suites 29, archives 28, accueil enfants 27, spa 26, refuge 25. Les canaux de hasard séparés sélectionnent variante, décoration, danger et anomalie. Le refuge, l'accueil initial et la respiration narrative du niveau 27 restent protégés des événements hostiles.

La graine permet de retrouver une partie avec le même code et le même environnement moteur. Elle ne constitue pas une garantie de reproduction entre toutes les versions : Godot indique que l'algorithme interne du générateur aléatoire est un détail d'implémentation. [Documentation Godot RandomNumberGenerator](https://docs.godotengine.org/en/stable/classes/class_randomnumbergenerator.html)

La sauvegarde actuelle contient une version de schéma, la graine, le niveau de reprise, les ressources, le temps, les étages visités et les listes de personnes sauvées, indices et caisses utilisées. Le chargeur refuse les types incorrects, nombres non finis, champs manquants et tailles excessives. L'écriture passe par un fichier temporaire voisin avant remplacement. Le principe de sérialiser explicitement les informations persistantes correspond au fonctionnement présenté par Godot. [Documentation Godot Saving games](https://docs.godotengine.org/en/stable/tutorials/io/saving_games.html)

L'identité courante `type_étage`, par exemple `survivor_28`, convient à un objet de chaque type par étage. La campagne devra adopter des identifiants indépendants de l'ordre de création, tels que `aube/28/archive/samuel`. Ajouter `generation_version`, `content_revision` et le manifeste des étages générés au format de sauvegarde permettra de migrer les données et de charger la même disposition après un portage. Ne pas sauvegarder les adresses des acteurs ou leurs indices dans un tableau.

## Air respirable et perception

La variable actuelle appelée `oxygen` représente une **réserve abstraite d'air respiratoire**, normalisée de 0 à 100. Elle diminue dans les étages marqués fumée ; une caisse la remplace. À épuisement dans la fumée, la santé diminue. Le jeu ne mesure pas actuellement la teneur ambiante en oxygène, la pression d'une bouteille ou une consommation respiratoire physiologique.

Pour la version complète, distinguer trois éléments dans les données et l'interface : mesure d'atmosphère du capteur, autonomie du dispositif respiratoire et exposition à un danger. Une atmosphère signalée dangereuse ne doit pas vider instantanément une bouteille ; une bouteille pleine ne doit pas afficher un air ambiant sain. Les seuils et durées seront des paramètres d'équilibrage clairement présentés au joueur.

Le stress est aujourd'hui un indicateur de tension modulé par les événements, la radio et les espaces sûrs. Il ne doit pas devenir un pourcentage arbitraire autorisant n'importe quelle hallucination. Le système futur distinguera événements objectifs, perceptions individuelles et preuves persistantes, chacun avec des conditions et un contre-jeu définis dans la bible.

## Répartition proposée sous Unreal Engine 5

La structure suivante est une recommandation de portage, pas une liste de classes déjà créées. Conserver les règles testables en C++ et exposer aux Blueprints les paramètres, présentations et assemblages de niveaux.

| Élément proposé | Responsabilité |
| --- | --- |
| `ADescentCharacter` | Avatar, caméra, posture et équipement visible |
| `UDescentMovementComponent` | Marche et mode de rappel contrôlé |
| `URescueInteractionComponent` | Recherche de cible, portée, visibilité et actions |
| `URescueMissionSubsystem` | Objectifs, personnes secourues et états de progression |
| `UFloorGenerationSubsystem` | Manifeste déterministe et validation des étages |
| `UFloorStreamingSubsystem` | Chargement des niveaux nécessaires et restauration de leurs états |
| `UAtmosphereComponent` | Danger local, exposition et consommation des réserves |
| `UDescentSaveGame` | Données persistantes versionnées |
| Blueprints de modules | Pièces, portes, points d'ancrage, accessoires et mise en scène |
| Widgets UMG | Interface, radio, journal et réglages |

Créer des actions Enhanced Input pour marcher, regarder, s'attacher, monter, descendre, poser un ancrage, utiliser le matériel et ouvrir le journal. Des contextes distincts « marche », « rappel » et « interface » clarifieront les commandes. Epic documente précisément les actions, contextes et changements de contexte à l'exécution. [Documentation Epic Enhanced Input](https://dev.epicgames.com/documentation/en-us/unreal-engine/enhanced-input-in-unreal-engine)

## Portage du rappel

La première étape UE doit reproduire le rappel guidé actuel avant d'ajouter une physique plus libre. Utiliser un mode de mouvement personnalisé associé au personnage, avec une longueur de corde, un point d'ancrage, une vitesse de descente et une limite latérale explicites. Le mouvement de la capsule doit vérifier les collisions ; quitter la corde nécessite une surface d'appui et un volume libre.

Le Character Movement Component fournit les modes standards et le cadre des mouvements personnalisés. Son intégration réseau ne rend cependant pas automatiquement répliquée une nouvelle mécanique de corde : les états et commandes supplémentaires devront être traités lors d'une phase dédiée. [Documentation Epic Character Movement](https://dev.epicgames.com/documentation/en-us/unreal-engine/understanding-networked-movement-in-the-character-movement-component-for-unreal-engine)

Un Cable Component pourra afficher la ligne et ses oscillations. Epic décrit une simulation par particules contraintes ; le choix proposé est de l'utiliser pour la présentation, tandis que le contrôleur conserve l'autorité sur le déplacement jouable. Cela évite de faire dépendre le passage d'une porte d'une instabilité de câble décoratif. [Documentation Epic Cable Components](https://dev.epicgames.com/documentation/en-us/unreal-engine/cable-components-in-unreal-engine)

Les ancrages futurs seront des points autorisés avec identifiant, support et état. La pose ne coupera jamais silencieusement la ligne principale. Tester la reprise de corde, le retour sur dalle, la pause et la restauration après sauvegarde avant d'introduire le secours simultané de plusieurs personnes.

## Chargement des étages et état des acteurs

Le prototype construit actuellement les six niveaux et l'extérieur ensemble. Pour la campagne, conserver un niveau persistant léger contenant le ciel, la mer, les silhouettes des tours et la structure du puits. Charger les intérieurs proches du joueur, puis anticiper l'étage suivant pendant la descente. Garder chargés les éléments nécessaires à une victime en cours de treuillage.

Un choix initial raisonnable est l'étage courant, celui du dessus et celui du dessous, avec marge supplémentaire près d'une transition. Ce budget reste à mesurer sur la machine cible. Le Level Streaming d'Unreal permet de charger, décharger et masquer des niveaux par volumes, Blueprints ou C++. [Documentation Epic Level Streaming](https://dev.epicgames.com/documentation/en-us/unreal-engine/level-streaming-overview-in-unreal-engine)

Avant déchargement, transférer les états utiles dans un registre indépendant des acteurs : victime évacuée, indice lu, porte ouverte, ancrage posé. Au retour, reconstruire le module puis appliquer ce registre. Une silhouette extérieure simplifiée peut rester visible sans maintenir tout son intérieur. World Partition pourra être évalué pour l'île élargie ; il n'est pas un préalable au premier bâtiment vertical.

## Procédural et effondrements futurs

Le générateur de campagne doit d'abord assembler un graphe praticable : entrée, sortie, secours, ravitaillement et chemin de retour. Il doit ensuite vérifier les largeurs, ressources nécessaires et respirations narratives. Les variantes décoratives viennent après cette validation.

Le framework PCG d'Unreal constitue une option pour distribuer végétation, gravats et accessoires à partir de règles. Il ne doit pas remplacer les invariants de sauvetage ou décider seul de la progression narrative. Cette utilisation est une proposition adaptée au rôle de génération procédurale décrit par Epic. [Documentation Epic PCG](https://dev.epicgames.com/documentation/en-us/unreal-engine/procedural-content-generation-framework-in-unreal-engine)

La tour penchée du prototype est un décor statique. Pour les grandes ruptures de la campagne, produire des séquences préparées avec états avant et après, volumes de sécurité, nouvelles collisions et points de reprise. La chute vers le bassin puis les souterrains doit être une transition de chapitre contrôlée. Une simulation structurelle complète des deux tours n'est pas prévue : elle compliquerait le sauvetage, la reproductibilité et la sauvegarde sans garantir une meilleure scène.

## Sauvegarde UE et coopération ultérieure

Transposer les données persistantes vers une classe `USaveGame`, en conservant les identifiants du contenu et les versions du manifeste. Epic prévoit les écritures synchrones et asynchrones et recommande la voie asynchrone pour éviter une interruption perceptible pendant le jeu. Tester explicitement le comportement en cas de fichier absent, version ancienne et écriture interrompue. [Documentation Epic Saving and Loading](https://dev.epicgames.com/documentation/en-us/unreal-engine/saving-and-loading-your-game-in-unreal-engine)

La coopération constitue un chantier distinct. Définir d'abord l'autorité sur les victimes, le treuil et les ressources partagées. Une hallucination individuelle doit rester une perception locale ; la mort d'un PNJ ou l'ouverture d'un passage doit être un état commun. Tester ensuite déconnexion, retour d'un joueur et chargement d'étages avec deux équipiers éloignés. Aucune de ces fonctions n'est présente dans cette livraison.

## Phases et critères de passage

Les objectifs suivants sont des critères proposés, pas des mesures de performance déjà obtenues.

| Phase | Livrable et critère vérifiable |
| --- | --- |
| Consolider la tranche Godot | Trois sauvetages complets, retour au menu puis reprise, aucune duplication de ressources et aucun passage obligatoire condamné sur un lot de graines |
| Extraire les systèmes | Modules mission et interaction séparés ; tests inchangés ; identifiants uniques et manifeste versionné |
| Reproduire sous UE5 | Même boucle sur un toit et deux étages ; marche et rappel sûrs ; commandes clavier et manette ; aucune progression perdue après recharge |
| Étendre à six étages UE | Parité des objectifs, dangers, indices, refuge et options de confort ; comparaison avec une grille de validation commune |
| Charger la campagne | Au moins trente variantes assemblées ; ressources bornées ; transitions sans vide visible ; mesure mémoire et temps de chargement sur matériel nommé |
| Produire le chapitre souterrain | Chute préparée, reprise cohérente, Alma et première créature intégrées à une séquence terminable |
| Évaluer la coopération | Prototype réseau séparé ; attribution exclusive des secours, retour après déconnexion et scénarios à deux joueurs vérifiés |

Les risques immédiats sont le couplage du contrôleur principal, l'absence de navigation de PNJ, la capsule d'accroupissement inchangée, les interactions encore fondées sur proximité et les limites des identifiants actuels. Les traiter avant de multiplier les étages évitera de transporter ces simplifications dans toute la campagne.

La fidélité du portage se jugera d'abord sur une intervention que l'on peut commencer, comprendre, terminer et reprendre. La qualité des personnages, animations, effets, ambiances et effondrements viendra ensuite enrichir cette base, avec un budget graphique établi à partir de mesures réelles.
