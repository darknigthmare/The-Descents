# Systèmes procéduraux de The Tower Descent

## Objet et périmètre

Le prototype assemble une descente de six étages, du restaurant panoramique 30 au refuge technique 25. Sa génération varie la disposition des accessoires, certaines conditions de danger et les manifestations secondaires. Elle conserve les fonctions architecturales, les trois victimes à sauver, les trois indices et les ressources nécessaires. Le résultat est un parcours de sauvetage lisible dont certains détails changent à chaque graine.

Ce document distingue ce mécanisme livré de la génération plus ambitieuse de la campagne, décrite dans la bible. Il ne faut pas interpréter les trente étages de la bible comme trente niveaux déjà jouables. La géométrie du prototype est construite par `world_builder.gd`; `floor_generator.gd` ne prétend pas, à lui seul, prouver la traversabilité des collisions produites.

## Contrat des données livrées

`FloorGenerator.generate(seed_value: int) -> Array` renvoie six dictionnaires, toujours dans l’ordre 30, 29, 28, 27, 26, 25. L’appel ne modifie ni le monde ni une sauvegarde. `FloorGenerator.validate(floors: Array) -> Array[String]` renvoie une liste vide si les invariants de contenu sont respectés et des erreurs lisibles dans le cas contraire.

| Champ | Type | Usage |
|---|---|---|
| `number` | entier | Identité et ordre de l’étage |
| `theme` | chaîne | Famille de modules architecturaux |
| `name` | chaîne | Nom français présenté au joueur |
| `safe` | booléen | Refuge dont la sécurité est garantie |
| `hazard` | chaîne | `none`, `smoke`, `water` ou `unstable` |
| `survivor` | booléen | Présence d’une victime du scénario |
| `evidence` | booléen | Présence d’un indice du scénario |
| `supplies` | booléen | Présence de matériel récupérable |
| `anomaly` | chaîne | `none`, `footsteps`, `radio` ou `figure` |
| `layout_variant` | entier de 0 à 2 | Variante du placement prévu par le constructeur |
| `prop_seed` | entier positif ou nul | Sous-graine réservée aux accessoires |
| `survivor_name` | chaîne | Identité stable du rescapé, sinon chaîne vide |
| `evidence_title` | chaîne | Titre de l’indice, sinon chaîne vide |
| `evidence_text` | chaîne | Texte complet de l’indice, sinon chaîne vide |

## Invariants de la descente

| Niveau | Fonction fixe | Sauvetage | Indice | Ressources | Variation autorisée |
|---|---|---|---|---|---|
| Toit | Dépose et poste de commandement | Équipe déjà présente | Briefing | Équipement initial | Mise en scène, hors générateur |
| 30 | Restaurant panoramique | Ana Rios | Aucun | Aucune cache | Accessoires et disposition; aucun danger ni apparition |
| 29 | Suites d’hôtel | Aucun | Chambre 2908 | Stock accessible | Fumée ou instabilité possibles; bruits de pas possibles |
| 28 | Bureaux et archives | Samuel Breton | Aucun | Aucune cache | Fumée ou instabilité possibles; anomalie radio possible |
| 27 | Jardin d’enfants évacué | Aucun | Le dessin des deux tours | Aucune cache | Accessoires; pause mécanique garantie |
| 26 | Spa et piscine | Nora Haddad | Relevé SILLAGE 06 | Aucune cache | Eau possible; apparition visuelle garantie |
| 25 | Refuge de maintenance | Point de regroupement | Bilan | Réapprovisionnement | Accessoires; sécurité garantie |

Les trois sauvés ne sont pas tirés au sort. Un joueur ne perd donc pas un objectif obligatoire parce que la graine l’a omis. Les indices qui établissent l’existence d’événements avant la catastrophe ne disparaissent pas non plus. Les étages 30, 27 et 25 sont mécaniquement calmes. L’étage 27 donne une respiration avant la première apparition lisible au 26; cela garantit qu’il n’existe jamais trois étages hostiles consécutifs.

Le statut `safe` est réservé au refuge 25. Une pause au 27 signifie seulement l’absence de danger ou d’anomalie programmés à cet étage dans le prototype. Elle n’ajoute pas de stock ni de point de sauvegarde implicite.

## Reproductibilité et séparation des tirages

Chaque étage possède quatre générateurs locaux indépendants : `layout`, `props`, `hazard` et `anomaly`. Leur graine est le hachage d’un identifiant comprenant le titre du projet, la graine de partie, le numéro d’étage, le nom du canal et la version de génération. Ajouter un tirage d’accessoire n’avance donc pas le générateur d’événements. Le générateur global de Godot n’est jamais utilisé pour déterminer les spécifications.

Godot documente qu’une graine donnée de `RandomNumberGenerator` reproduit une séquence, tout en précisant que l’algorithme sous-jacent reste un détail d’implémentation. La garantie de cette livraison s’applique donc à la même version du générateur et du moteur. Une migration de moteur doit conserver le manifeste déjà généré dans la sauvegarde ou fournir une migration explicite; conserver uniquement le nombre de la graine ne constitue pas une promesse de compatibilité éternelle. [Documentation officielle de RandomNumberGenerator](https://docs.godotengine.org/en/stable/classes/class_randomnumbergenerator.html)

Dans le prototype, `GENERATION_VERSION` vaut 1. Le choix de graine ne dépend ni de l’heure ni de la vitesse du processeur. Des entiers négatifs sont acceptés comme identifiants de partie et transformés par le même hachage. Le moteur décide ensuite comment exploiter la valeur `prop_seed`; il ne doit pas introduire de nouveaux tirages globaux qui rendraient les accessoires sensibles à l’ordre de chargement.

## Ce que les tests vérifient

Exécuter depuis la racine du dépôt :

```sh
godot --headless --path prototype --script tests/test_generation.gd
```

Le test parcourt 200 graines. Il exige l’égalité de deux générations successives, l’indépendance vis-à-vis de tirages globaux intercalés, l’absence d’état mutable partagé et la validation de chaque résultat. Il vérifie que ce corpus exerce les trois variantes de disposition, les quatre états de danger et les quatre états d’anomalie. Il couvre aussi des entiers limites et des entrées invalides : liste vide, mauvais type, champ absent, refuge rendu dangereux, survivant obligatoire supprimé et succession de trois niveaux hostiles. Une anomalie entraîne un code de sortie non nul et un message explicite.

Ces vérifications portent sur le contrat des données. La collision d’une table avec un chemin, le rayon d’interaction d’un PNJ, la lisibilité d’une sortie, la bonne dépense d’oxygène et la persistance des victimes évacuées exigent des tests de scène et de progression distincts. Un succès du test de génération ne doit jamais être présenté comme la validation complète d’une partie.

## Vérification des trajets physiques du prototype

Le test complémentaire `tests/test_routes.gd` construit le monde et utilise la véritable capsule du personnage avec `move_and_slide`, la gravité et les collisions du décor. Il place seulement le personnage au départ de chaque étage; ensuite, chaque aller vers un objectif et chaque retour à la balise est parcouru par le moteur physique. Aucun passage n’utilise de téléportation, de désactivation des collisions ou de modification du décor.

```sh
godot --headless --fixed-fps 60 --path prototype --script tests/test_routes.gd
```

Les graines 3, 47 et 69 forment un ensemble couvrant les variantes de modules 0, 1 et 2 sur chacun des six étages. Le test suit les voies prévues autour du puits vers les trois survivants, les trois indices, les deux réserves et le refuge. Il s’arrête à portée d’interaction des objets, dont certains comportent leur propre collision, puis revient au treuil. La vitesse est de 3,7 mètres par seconde à l’aller et de 2,4 pendant le retour avec une victime.

La vérification effectuée pour cette version a réussi 205 contrôles, correspondant à 150 segments de déplacement et 27 approches d’objectifs avec retour. Elle établit que ces trajets critiques sont praticables dans les trois configurations testées. Elle ne prétend pas couvrir toutes les positions possibles, les sauts, toutes les graines ni l’ensemble de la campagne. La logique de mission, les pauses et les reprises sont testées séparément dans `tests/test_mission.gd`; l’interface et la visibilité des chemins exigent aussi une inspection visuelle.

## Extension prévue pour la campagne

La campagne doit conserver un squelette conçu à la main : toiture, jonction des tours, refuge intermédiaire, sauvetage d’Alma, chute dans la piscine, sous-sols, cavernes, bunker et seuil 666. La génération peut choisir les pièces secondaires et l’état des connexions, mais ne doit pas effacer ces événements ou les placer hors de leur ordre narratif.

La proposition de génération complète comporte cinq passes :

1. **Plan d’étage.** Choisir une grammaire compatible avec la fonction du lieu : hôtel à couloirs et chambres, bureaux à plateaux, piscine à volume central, laboratoire à sas. Préserver les noyaux porteurs et les gaines verticales entre les étages.
2. **Dommages.** Poser l’eau, les ruptures de dalles et les coupures électriques en tenant compte des connexions physiques. Un étage inondé ne doit pas être posé au-dessus d’un trou ouvert sans mécanisme d’écoulement lisible.
3. **Objectifs.** Placer le rescapé, son état, le point de stabilisation et le trajet vers la ligne d’extraction. Vérifier le chemin avant de poser les accessoires secondaires.
4. **Ressources et tension.** Garantir un budget de traversée et une marge de retour avant tout événement facultatif. Poser un temps calme après un événement majeur; préserver la fiabilité des refuges annoncés.
5. **Validation et réparation.** Vérifier la connexion entrée–objectif–sortie, les capacités requises, la portée des points d’ancrage, le dégagement de la civière et la visibilité des signaux essentiels. Remplacer un module invalide par une variante de secours au lieu de relancer indéfiniment la génération.

Ces passes de campagne sont des objectifs d’implémentation, pas des fonctionnalités présentes dans le générateur de six étages.

## Contraintes de progression à conserver

Un itinéraire obligatoire ne dépend jamais d’un consommable tiré aléatoirement. Si une porte nécessite un outil particulier, cet outil est garanti en amont et ne peut pas être dépensé définitivement avant la porte. Un objet facultatif peut réduire un danger ou ouvrir un raccourci, mais son absence n’efface pas le chemin principal.

Les ancres imposées par le parcours sont stables. Les points facultatifs peuvent réduire le balancement et raccourcir une extraction. La simulation doit conserver au moins une manière de rejoindre le refuge ou le dernier point de repli avant la rupture scénarisée de l’acte II. Après cette rupture, le jeu annonce un nouvel objectif et une nouvelle réserve minimale; il ne réutilise pas silencieusement une route de retour devenue impossible.

Une hallucination peut troubler une voix, une silhouette ou la lecture momentanée d’un espace secondaire. Elle ne transforme pas sans signal un refuge en piège, ne supprime pas un rescapé déjà évacué et ne consomme pas un objet en prétendant ensuite que son utilisation n’a jamais eu lieu. La confiance dans les conséquences mécaniques rend l’incertitude narrative plus forte.

## Stockage des checkpoints du prototype

Le composant livré `DescentSave`, dans `prototype/scripts/save_store.gd`, expose deux fonctions statiques : `save_data(data, path)` renvoie un code `Error`; `load_data(path)` renvoie le checkpoint normalisé ou `{}` si aucun fichier exploitable n’est disponible. Le chemin par défaut est `user://save_v1.json`, dans les données locales du jeu. Les erreurs d’écriture doivent être affichées par l’interface; un retour non nul ne signifie pas que le checkpoint est enregistré.

La version 1 exige exactement les champs `version`, `seed`, `floor`, `health`, `oxygen`, `stress`, `anchors`, `flares`, `rescued`, `clues`, `supplies_used`, `elapsed`, `seen_floors` et `completed`. Les champs supplémentaires et les versions inconnues sont refusés. Les jauges sont des nombres finis entre 0 et 100, les ancres entre 0 et 8, les fusées entre 0 et 6, la graine entre 1 et 999999 et le numéro de reprise entre 25 et 31. Les identifiants collectés sont des chaînes non vides, uniques dans chaque liste, limitées à 80 caractères et 64 éléments. Les étages vus sont des entiers distincts entre 25 et 31. Le temps écoulé est fini et positif ou nul.

Le stockage n’interprète pas la géométrie : `floor = 29` désigne une reprise à l’emplacement choisi par le contrôleur, pas la preuve que tout l’étage est sans danger. Le contrôleur doit créer le checkpoint uniquement au point autorisé et rétablir un emplacement stable. Le magasin ne sauvegarde pas une position arbitraire au milieu d’une corde.

Avant toute écriture, le dictionnaire est validé et copié sans modification de l’entrée. Les données sont écrites dans un fichier temporaire voisin, vidées vers le système de fichiers, puis renommées sur le checkpoint. Le fichier précédent n’est jamais supprimé avant cette substitution. Cela évite qu’une sauvegarde normalement interrompue pendant l’écriture du temporaire remplace un fichier valide. Cette séquence ne constitue pas une garantie matérielle contre toute panne de disque ou coupure électrique.

À la lecture, la taille est limitée à 64 Kio avant le décodage JSON. Les données invalides, tronquées ou d’une version inconnue sont rejetées sans lancer d’exception dans le jeu. Le décodage JSON ne préserve pas le type entier de GDScript : les champs entiers sont donc restaurés uniquement si leur valeur est mathématiquement entière et dans les bornes prévues. Les booléens et chaînes numériques ne sont jamais traités comme des nombres. [Documentation officielle de JSON](https://docs.godotengine.org/en/stable/classes/class_json.html) · [FileAccess](https://docs.godotengine.org/en/stable/classes/class_fileaccess.html) · [DirAccess](https://docs.godotengine.org/en/stable/classes/class_diraccess.html)

Le test dédié se lance avec `godot --headless --path prototype --script tests/test_save.gd`. Il vérifie l’aller-retour des valeurs, le remplacement d’un checkpoint existant, l’absence de mutation, les types et bornes invalides, le refus des versions inconnues, les fichiers corrompus ou trop grands, les erreurs d’écriture et l’ignorance d’un temporaire interrompu.

## Sauvegarde de campagne et futurs outils de production

Pour une version ultérieure, enregistrer ensemble la graine, la version de génération, le manifeste complet, les objectifs résolus, les ressources ramassées, les ancres posées et les événements déjà joués. Un rechargement doit restaurer un monde, pas rerouler les dangers. Les identifiants des objets doivent dériver de l’étage et de leur rôle, et rester indépendants de leur position exacte.

Un outil d’édition utile afficherait la pile des trente niveaux, les connexions verticales, le budget d’oxygène requis, les espaces de retournement des civières et la dernière validation. Son export JSON pourrait être consommé aussi bien par Godot que par une future implémentation Unreal Engine 5. Cette séparation entre manifeste, construction et état de partie constitue la partie à préserver lors d’un changement de moteur.
